vim.cmd([[ let g:neo_tree_remove_legacy_commands = 1 ]])

vim.fn.sign_define("DiagnosticSignError", {text = " ", texthl = "DiagnosticSignError"})
vim.fn.sign_define("DiagnosticSignWarn", {text = " ", texthl = "DiagnosticSignWarn"})
vim.fn.sign_define("DiagnosticSignInfo", {text = " ", texthl = "DiagnosticSignInfo"})
vim.fn.sign_define("DiagnosticSignHint", {text = "󰌵", texthl = "DiagnosticSignHint"})

-- Shift-h - для изменения видимости скрытых файлов
-- BackSpace - для перехода в родительскую директорию
-- . - для изменения корневой директории на выбранную
-- a - добавить файл
-- r - переименовать файл
-- R - обновить

require("neo-tree").setup({
    -- filesystem = {
    --    filtered_items = {
            -- visible = true, -- This is what you want: If you set this to `true`, all "hide" just mean "dimmed out"
            -- hide_dotfiles = false,
            -- hide_gitignored = true,
    --    }
    -- }
})
