local lualine = require'lualine'

lualine.setup({
    options = {
        theme = 'tokyonight'
        -- ... your lualine config
    }
})
