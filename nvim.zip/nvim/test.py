import collections

def my_func():
    pass

my_func()

collections.Counter()
